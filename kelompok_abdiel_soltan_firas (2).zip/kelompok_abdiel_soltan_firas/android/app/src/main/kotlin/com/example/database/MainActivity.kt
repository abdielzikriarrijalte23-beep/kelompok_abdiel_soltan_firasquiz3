package com.example.database

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
