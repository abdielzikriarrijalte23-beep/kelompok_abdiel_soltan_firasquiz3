// screens/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/database_service.dart';
import '../models/mahasiswa.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final DatabaseService _dbService = DatabaseService();
  String? userId;

  // State untuk Search, Filter, dan Sort
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  String _filterHobi = "Semua";
  String _sortOrder = "Nama (A-Z)";
  
  final List<String> _hobiList = ["Semua", "Masak", "Olahraga", "Membaca", "Gaming", "Menulis"];
  final List<String> _sortList = ["Nama (A-Z)", "Nama (Z-A)", "NIM (Asc)", "NIM (Desc)"];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text;
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments;
    if (args != null) {
      userId = args as String;
    } else {
      Navigator.of(context).pushReplacementNamed('/login');
    }
  }

  void _navigateToAbout() {
    Navigator.of(context).pushNamed('/about');
  }

  // --- FUNGSI BARU: Navigasi ke Profil ---
  void _navigateToProfile() {
    // Kirim userId ke halaman profile agar bisa load data yang sesuai
    Navigator.of(context).pushNamed('/profile', arguments: userId);
  }

  void _navigateToAddScreen() {
    Navigator.of(context).pushNamed('/addEdit', arguments: {'userId': userId});
  }

  void _navigateToDetailScreen(String docId, Mahasiswa mahasiswa) {
    Navigator.of(context).pushNamed(
      '/detail',
      arguments: {
        'userId': userId,
        'docId': docId,
        'mahasiswa': mahasiswa,
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (userId == null) {
      return Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Data Mahasiswa'),
        actions: [
          // --- TOMBOL BARU: Profil Saya ---
          IconButton(
            icon: Icon(Icons.account_circle), 
            onPressed: _navigateToProfile,
            tooltip: 'Profil Saya',
          ),
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: _navigateToAbout,
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // --- UI Search & Filter ---
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Cari berdasarkan Nama atau NIM',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () => _searchController.clear(),
                      )
                    : null,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonHideUnderline(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.0),
                      decoration: BoxDecoration(
                        color: Theme.of(context).dividerColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: DropdownButton<String>(
                        value: _filterHobi,
                        isExpanded: true,
                        items: _hobiList.map((String hobi) {
                          return DropdownMenuItem<String>(value: hobi, child: Text(hobi));
                        }).toList(),
                        onChanged: (val) => setState(() => _filterHobi = val!),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonHideUnderline(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.0),
                      decoration: BoxDecoration(
                        color: Theme.of(context).dividerColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: DropdownButton<String>(
                        value: _sortOrder,
                        isExpanded: true,
                        items: _sortList.map((String sort) {
                          return DropdownMenuItem<String>(value: sort, child: Text(sort));
                        }).toList(),
                        onChanged: (val) => setState(() => _sortOrder = val!),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // --- List Data ---
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _dbService.getMahasiswaStream(userId!),
              builder: (context, snapshot) {
                if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
                if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) return Center(child: Text('Belum ada data mahasiswa.'));

                // Logika Filter & Sort
                List<DocumentSnapshot> docs = snapshot.data!.docs;

                if (_searchQuery.isNotEmpty) {
                  String query = _searchQuery.toLowerCase();
                  docs = docs.where((doc) {
                    Mahasiswa m = Mahasiswa.fromFirestore(doc);
                    return m.nama.toLowerCase().contains(query) || m.nim.toLowerCase().contains(query);
                  }).toList();
                }

                if (_filterHobi != "Semua") {
                  docs = docs.where((doc) {
                    Mahasiswa m = Mahasiswa.fromFirestore(doc);
                    return m.hobi.toLowerCase() == _filterHobi.toLowerCase();
                  }).toList();
                }

                docs.sort((a, b) {
                  Mahasiswa mA = Mahasiswa.fromFirestore(a);
                  Mahasiswa mB = Mahasiswa.fromFirestore(b);
                  switch (_sortOrder) {
                    case "Nama (A-Z)": return mA.nama.compareTo(mB.nama);
                    case "Nama (Z-A)": return mB.nama.compareTo(mA.nama);
                    case "NIM (Asc)": return mA.nim.compareTo(mB.nim);
                    case "NIM (Desc)": return mB.nim.compareTo(mA.nim);
                    default: return mA.nama.compareTo(mB.nama);
                  }
                });

                if (docs.isEmpty) return Center(child: Text('Tidak ada data yang cocok.'));

                return ListView.builder(
                  itemCount: docs.length,
                  padding: EdgeInsets.all(8.0),
                  itemBuilder: (context, index) {
                    DocumentSnapshot document = docs[index];
                    Mahasiswa mahasiswa = Mahasiswa.fromFirestore(document);
                    String docId = document.id;

                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 4.0),
                      child: ListTile(
                        leading: CircleAvatar(
                          radius: 25,
                          backgroundColor: Theme.of(context).dividerColor,
                          child: mahasiswa.fotoUrl.isNotEmpty
                              ? ClipOval(
                                  child: Image.network(
                                    mahasiswa.fotoUrl,
                                    fit: BoxFit.cover, width: 50, height: 50,
                                    errorBuilder: (c, e, s) => Icon(Icons.person, color: Colors.grey[800]),
                                  ),
                                )
                              : Icon(Icons.person, color: Colors.grey[800]),
                        ),
                        title: Text(mahasiswa.nama, style: TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('NIM: ${mahasiswa.nim} | Hobi: ${mahasiswa.hobi}'),
                        onTap: () => _navigateToDetailScreen(docId, mahasiswa),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddScreen,
        child: Icon(Icons.add),
        tooltip: 'Tambah Data',
      ),
    );
  }
}