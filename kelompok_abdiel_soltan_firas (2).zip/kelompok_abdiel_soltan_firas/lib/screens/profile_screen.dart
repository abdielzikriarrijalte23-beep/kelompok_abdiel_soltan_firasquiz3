// screens/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
// BARU: Import Firebase Auth untuk mendapatkan info user
import 'package:firebase_auth/firebase_auth.dart';
import '../services/database_service.dart';
import '../models/mahasiswa.dart'; // Kita akan gunakan ulang model Mahasiswa

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dbService = DatabaseService();
  String? userId;

  // BARU: State untuk menyimpan email user
  String? _userEmail;

  // Controllers untuk setiap field
  final _fotoUrlController = TextEditingController();
  final _namaController = TextEditingController();
  final _nimController = TextEditingController();
  final _tglLahirController = TextEditingController();
  final _hobiController = TextEditingController();
  final _nomorHpController = TextEditingController();
  final _alamatController = TextEditingController();

  bool _isLoading = true; // Loading saat data diambil
  bool _isEditing = false; // State untuk mengontrol mode tampilan

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // BARU: Ambil email dari Firebase Auth
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        setState(() {
          _userEmail = currentUser.email;
        });
      }

      // Kode Anda sebelumnya untuk mengambil arguments
      final args = ModalRoute.of(context)!.settings.arguments;
      if (args != null) {
        userId = args as String;
        _loadProfileData(); // Muat data profil
      } else {
        Navigator.of(context).pop();
      }
    });
  }

  void _loadProfileData() async {
    if (userId == null) return;

    setState(() { _isLoading = true; });

    DocumentSnapshot? doc = await _dbService.getUserProfile(userId!);
    
    if (doc != null && doc.exists) {
      Mahasiswa profile = Mahasiswa.fromFirestore(doc);
      _fotoUrlController.text = profile.fotoUrl;
      _namaController.text = profile.nama;
      _nimController.text = profile.nim;
      _tglLahirController.text = profile.tglLahir;
      _hobiController.text = profile.hobi;
      _nomorHpController.text = profile.nomorHp;
      _alamatController.text = profile.alamat;
      
      setState(() { _isEditing = false; }); 
    } else {
      setState(() { _isEditing = true; }); 
    }

    setState(() { _isLoading = false; });
  }

  @override
  void dispose() {
    _fotoUrlController.dispose();
    _namaController.dispose();
    _nimController.dispose();
    _tglLahirController.dispose();
    _hobiController.dispose();
    _nomorHpController.dispose();
    _alamatController.dispose();
    super.dispose();
  }

  void _submitData() async {
    if (_formKey.currentState!.validate()) {
      if (userId == null) return;

      setState(() { _isLoading = true; });

      Mahasiswa profile = Mahasiswa(
        fotoUrl: _fotoUrlController.text.trim(),
        nama: _namaController.text.trim(),
        nim: _nimController.text.trim(),
        tglLahir: _tglLahirController.text.trim(),
        hobi: _hobiController.text.trim(),
        nomorHp: _nomorHpController.text.trim(),
        alamat: _alamatController.text.trim(),
      );

      try {
        await _dbService.updateUserProfile(userId!, profile.toMap());
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Profil berhasil diperbarui')),
          );
          setState(() {
            _isEditing = false;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Gagal menyimpan profil: $e')),
          );
        }
      }

      if (mounted) {
        setState(() { _isLoading = false; });
      }
    }
  }

  // Tampilan Form Edit
  Widget _buildEditForm() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: ListView(
          children: [
            // BARU: Tampilkan email di mode edit
            if (_userEmail != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  'Mengedit profil untuk: $_userEmail',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
              ),

            TextFormField(
              controller: _fotoUrlController,
              keyboardType: TextInputType.url,
              decoration: InputDecoration(
                labelText: 'Foto URL',
                hintText: 'https.://... (Opsional)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.link),
              ),
              validator: (value) { return null; },
            ),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_namaController, 'Nama Mahasiswa', Icons.person),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_nimController, 'NIM', Icons.badge),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_tglLahirController, 'Tanggal Lahir (DD-MM-YYYY)', Icons.calendar_today),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_hobiController, 'Hobi', Icons.favorite),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_nomorHpController, 'Nomor HP', Icons.phone),
            SizedBox(height: 10),
            _buildRequiredTextFormField(_alamatController, 'Alamat', Icons.home),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isLoading ? null : _submitData,
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
              ),
              child: _isLoading ? CircularProgressIndicator() : Text('Simpan Perubahan'),
            ),
          ],
        ),
      ),
    );
  }

  // Tampilan Detail Profil
  Widget _buildDetailView() {
    final fotoUrl = _fotoUrlController.text;
    final nama = _namaController.text;
    final nim = _nimController.text;

    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        Center(
          child: CircleAvatar(
            radius: 60,
            backgroundColor: Theme.of(context).dividerColor,
            child: fotoUrl.isNotEmpty
                ? ClipOval(
                    child: Image.network(
                      fotoUrl,
                      fit: BoxFit.cover,
                      width: 120,
                      height: 120,
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.person, size: 60, color: Colors.grey[800]);
                      },
                    ),
                  )
                : Icon(Icons.person, size: 60, color: Colors.grey[800]),
          ),
        ),
        SizedBox(height: 16),
        Center(
          child: Text(
            nama.isNotEmpty ? nama : "(Nama Belum Diisi)",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
        Center(
          child: Text(
            nim.isNotEmpty ? 'NIM: $nim' : "(NIM Belum Diisi)",
            style: TextStyle(fontSize: 16, color: Colors.grey[700]),
          ),
        ),
        SizedBox(height: 8), 

        //
        // --- INI ADALAH TAMBAHAN YANG ANDA MINTA ---
        //
        if (_userEmail != null)
          Center(
            child: Text(
              'Anda login sebagai: $_userEmail',
              style: TextStyle(fontSize: 14, color: Colors.grey[600], fontStyle: FontStyle.italic),
            ),
          ),
        //
        // --- AKHIR TAMBAHAN ---
        //
        
        SizedBox(height: 24),
        Divider(),
        _buildInfoRow(Icons.calendar_today, 'Tanggal Lahir', _tglLahirController.text),
        _buildInfoRow(Icons.favorite, 'Hobi', _hobiController.text),
        _buildInfoRow(Icons.phone, 'Nomor HP', _nomorHpController.text),
        _buildInfoRow(Icons.home, 'Alamat', _alamatController.text),
      ],
    );
  }

  // Helper untuk baris info di mode detail
  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary, size: 24),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                SizedBox(height: 2),
                Text(
                  value.isNotEmpty ? value : "(Belum diisi)", 
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper untuk form di mode edit
  Widget _buildRequiredTextFormField(
      TextEditingController controller, String label, IconData icon) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
        prefixIcon: Icon(icon),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label tidak boleh kosong';
        }
        return null;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Profil Saya' : 'Profil Saya'),
        actions: [
          if (!_isLoading && !_isEditing)
            IconButton(
              icon: Icon(Icons.edit),
              onPressed: () {
                setState(() {
                  _isEditing = true;
                });
              },
            ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _isEditing
              ? _buildEditForm() // Tampilkan Form Edit
              : _buildDetailView(), // Tampilkan Detail Profil
    );
  }
}