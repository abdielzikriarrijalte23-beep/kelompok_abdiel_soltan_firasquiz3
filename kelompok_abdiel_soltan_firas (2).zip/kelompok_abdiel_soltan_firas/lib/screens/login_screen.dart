// screens/login_screen.dart
import 'package:flutter/material.dart';
// BARU: Import Firebase Auth untuk login
import 'package:firebase_auth/firebase_auth.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // BARU: Buat instance FirebaseAuth
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // BARU: Ganti controller untuk email dan password
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  // BARU: Untuk show/hide password
  bool _isPasswordVisible = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // BARU: Fungsi _login diubah total untuk pakai Firebase Auth
  void _login() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // 1. Coba login dengan email dan password
        final UserCredential userCredential =
            await _auth.signInWithEmailAndPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        // 2. Jika berhasil, ambil User ID (uid) dari Auth
        if (userCredential.user != null) {
          String userId = userCredential.user!.uid; // Ini adalah User ID baru

          // 3. Kirim uid ke Dashboard
          if (mounted) {
            Navigator.of(context).pushReplacementNamed(
              '/dashboard',
              arguments: userId,
            );
          }
        }
      } on FirebaseAuthException catch (e) {
        // 4. Handle jika login gagal
        String message;
        if (e.code == 'user-not-found' || e.code == 'wrong-password') {
          message = 'Email atau password salah.';
        } else if (e.code == 'invalid-email') {
          message = 'Format email tidak valid.';
        } else {
          message = 'Terjadi kesalahan. Coba lagi.';
        }
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message)),
          );
        }
      } catch (e) {
        // Handle error lainnya
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: Gagal terhubung.')),
          );
        }
      }

      // 5. Hentikan loading
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // BARU: Fungsi untuk menampilkan dialog Lupa Password
  void _showPasswordResetDialog() {
    final _resetEmailController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Reset Password'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Masukkan email Anda untuk menerima link reset.'),
              SizedBox(height: 10),
              TextField(
                controller: _resetEmailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () async {
                String email = _resetEmailController.text.trim();
                if (email.isNotEmpty) {
                  try {
                    // Kirim email reset
                    await _auth.sendPasswordResetEmail(email: email);
                    
                    if (mounted) {
                      Navigator.of(context).pop(); // Tutup dialog
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Link reset password telah dikirim ke $email'),
                        ),
                      );
                    }
                  } on FirebaseAuthException catch (e) {
                    if (mounted) {
                       Navigator.of(context).pop(); // Tutup dialog
                       String message = "Email tidak terdaftar.";
                       if(e.code == 'invalid-email'){
                         message = "Format email salah.";
                       }
                       ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(message),
                        ),
                      );
                    }
                  }
                }
              },
              child: Text('Kirim'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Selamat Datang',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              
              // BARU: Input untuk Email
              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Email tidak boleh kosong';
                  }
                  if (!value.contains('@')) {
                    return 'Email tidak valid';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              
              // BARU: Input untuk Password
              TextFormField(
                controller: _passwordController,
                obscureText: !_isPasswordVisible, // Untuk hide/show password
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Password tidak boleh kosong';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10),
              
              // BARU: Tombol Lupa Password
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: _showPasswordResetDialog,
                  child: Text('Lupa Password?'),
                ),
              ),
              SizedBox(height: 10),

              _isLoading
                  ? CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(double.infinity, 50), // Buat tombol lebar
                      ),
                      child: Text('Masuk'),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}