// screens/detail_screen.dart
import 'package:flutter/material.dart';
import '../models/mahasiswa.dart';
import '../services/database_service.dart';

class DetailScreen extends StatelessWidget {
  final _dbService = DatabaseService();

  // Helper untuk membuat baris info
  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.blue, size: 24),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                SizedBox(height: 2),
                Text(value, style: TextStyle(color: Colors.black87, fontSize: 16, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Fungsi untuk Edit (sama seperti di dashboard)
  void _navigateToEditScreen(BuildContext context, String userId, String docId, Mahasiswa mahasiswa) {
    Navigator.of(context).pushNamed(
      '/addEdit',
      arguments: {
        'userId': userId,
        'docId': docId,
        'mahasiswa': mahasiswa,
      },
    );
  }

  // Fungsi untuk Delete (sama seperti di dashboard)
  void _deleteData(BuildContext context, String userId, String docId) async {
    // Tampilkan dialog konfirmasi
    bool? confirmed = await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Konfirmasi Hapus'),
        content: Text('Apakah Anda yakin ingin menghapus data ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text('Batal'),
          ),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await _dbService.deleteMahasiswa(userId, docId);
        if (context.mounted) {
          Navigator.of(context).pop(); // Kembali ke dashboard setelah hapus
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Data berhasil dihapus')),
          );
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Gagal menghapus data: $e')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Ambil arguments yang dikirim dari Dashboard
    final args = ModalRoute.of(context)!.settings.arguments as Map;
    final Mahasiswa mahasiswa = args['mahasiswa'];
    final String docId = args['docId'];
    final String userId = args['userId'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Mahasiswa'),
        // BARU: Tombol Edit & Delete dipindah ke sini
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => _navigateToEditScreen(context, userId, docId, mahasiswa),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _deleteData(context, userId, docId),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Bagian Foto
          Center(
            child: CircleAvatar(
              radius: 60,
              backgroundColor: Colors.grey[200],
              child: mahasiswa.fotoUrl.isNotEmpty
                  ? ClipOval(
                      child: Image.network(
                        mahasiswa.fotoUrl,
                        fit: BoxFit.cover,
                        width: 120,
                        height: 120,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(Icons.person, size: 60, color: Colors.grey[800]);
                        },
                      ),
                    )
                  : Icon(Icons.person, size: 60, color: Colors.grey[800]),
            ),
          ),
          SizedBox(height: 16),
          // Bagian Nama
          Center(
            child: Text(
              mahasiswa.nama,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          Center(
            child: Text(
              'NIM: ${mahasiswa.nim}',
              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
            ),
          ),
          SizedBox(height: 24),
          Divider(),
          
          // Bagian Detail Info
          _buildInfoRow(Icons.calendar_today, 'Tanggal Lahir', mahasiswa.tglLahir),
          _buildInfoRow(Icons.favorite, 'Hobi', mahasiswa.hobi),
          _buildInfoRow(Icons.phone, 'Nomor HP', mahasiswa.nomorHp),
          _buildInfoRow(Icons.home, 'Alamat', mahasiswa.alamat),
        ],
      ),
    );
  }
}