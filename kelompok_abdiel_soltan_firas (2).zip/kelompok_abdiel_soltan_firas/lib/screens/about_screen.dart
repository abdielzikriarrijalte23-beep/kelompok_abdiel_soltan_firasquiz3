// screens/about_screen.dart
import 'package:flutter/material.dart';
// BARU: Import provider untuk mengakses ThemeProvider
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart'; // Sesuaikan path jika perlu

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // BARU: Panggil provider. 
    // Kita tidak perlu 'watch' di sini, cukup 'read'
    final themeProvider = context.read<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Tentang Aplikasi'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          // Ubah dari 'center' ke 'start' agar lebih rapi
          mainAxisAlignment: MainAxisAlignment.start, 
          children: [
            SizedBox(height: 30),
            // Gunakan IconTheme untuk ganti warna ikon
            Icon(Icons.info, size: 80, color: Theme.of(context).colorScheme.primary),
            SizedBox(height: 20),
            Text(
              'Aplikasi CRUD Mahasiswa',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Versi 1.0.0',
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            ),
            SizedBox(height: 20),
            Text(
              'Dibuat menggunakan Flutter dan Firebase Firestore untuk mendemonstrasikan operasi Create, Read, Update, dan Delete (CRUD).',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            
            //
            // --- INI BAGIAN BARU (TOGGLE SWITCH) ---
            //
            SizedBox(height: 40),
            Divider(),
            // Kita gunakan 'Consumer' agar hanya switch ini yang di-build ulang
            // saat tema berganti, bukan seluruh halaman.
            Consumer<ThemeProvider>(
              builder: (context, provider, child) {
                return SwitchListTile(
                  title: Text('Mode Gelap (Dark Mode)'),
                  secondary: Icon(
                    provider.isDarkMode ? Icons.dark_mode : Icons.light_mode
                  ),
                  value: provider.isDarkMode,
                  onChanged: (bool value) {
                    // Panggil fungsi di provider untuk mengubah tema
                    provider.toggleTheme(value);
                  },
                );
              }
            ),
            Divider(),
            //
            // --- AKHIR BAGIAN BARU ---
            //
          ],
        ),
      ),
    );
  }
}