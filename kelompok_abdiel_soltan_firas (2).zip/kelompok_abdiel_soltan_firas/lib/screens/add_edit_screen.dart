// screens/add_edit_screen.dart
import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../models/mahasiswa.dart';

class AddEditScreen extends StatefulWidget {
  @override
  _AddEditScreenState createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dbService = DatabaseService();

  // Controllers untuk setiap field
  final _fotoUrlController = TextEditingController(); // <-- BARU
  final _namaController = TextEditingController();
  final _nimController = TextEditingController();
  final _tglLahirController = TextEditingController();
  final _hobiController = TextEditingController();
  final _nomorHpController = TextEditingController();
  final _alamatController = TextEditingController();

  String? userId;
  String? docId;
  Mahasiswa? initialData;
  bool isEditMode = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Ambil arguments
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    if (args != null) {
      userId = args['userId'];
      docId = args['docId']; // Akan null jika mode 'Add'
      initialData = args['mahasiswa']; // Akan null jika mode 'Add'

      if (docId != null && initialData != null) {
        // Ini adalah mode EDIT
        isEditMode = true;
        _fotoUrlController.text = initialData!.fotoUrl; // <-- BARU
        _namaController.text = initialData!.nama;
        _nimController.text = initialData!.nim;
        _tglLahirController.text = initialData!.tglLahir;
        _hobiController.text = initialData!.hobi;
        _nomorHpController.text = initialData!.nomorHp;
        _alamatController.text = initialData!.alamat;
      }
    }
  }

  @override
  void dispose() {
    // Bersihkan controllers
    _fotoUrlController.dispose(); // <-- BARU
    _namaController.dispose();
    _nimController.dispose();
    _tglLahirController.dispose();
    _hobiController.dispose();
    _nomorHpController.dispose();
    _alamatController.dispose();
    super.dispose();
  }

  void _submitData() async {
    if (_formKey.currentState!.validate()) {
      if (userId == null) return; // Seharusnya tidak terjadi

      // Pastikan semua data, termasuk fotoUrl, disertakan
      Mahasiswa mahasiswa = Mahasiswa(
        fotoUrl: _fotoUrlController.text.trim(), // <-- BARU
        nama: _namaController.text.trim(),
        nim: _nimController.text.trim(),
        tglLahir: _tglLahirController.text.trim(),
        hobi: _hobiController.text.trim(),
        nomorHp: _nomorHpController.text.trim(),
        alamat: _alamatController.text.trim(),
      );

      try {
        if (isEditMode) {
          // UPDATE
          await _dbService.updateMahasiswa(userId!, docId!, mahasiswa);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Data berhasil diperbarui')),
          );
        } else {
          // CREATE
          await _dbService.addMahasiswa(userId!, mahasiswa);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Data berhasil ditambahkan')),
          );
        }
        Navigator.of(context).pop(); // Kembali ke Dashboard
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal menyimpan data: $e')),
        );
      }
    }
  }

  // Helper untuk membuat TextFormField yang WAJIB DIISI
  Widget _buildRequiredTextFormField(
      TextEditingController controller, String label, IconData icon) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
        prefixIcon: Icon(icon),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label tidak boleh kosong';
        }
        return null;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditMode ? 'Edit Data Mahasiswa' : 'Tambah Data Mahasiswa'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              //
              // --- FIELD BARU UNTUK FOTO URL ---
              //
              TextFormField(
                controller: _fotoUrlController,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  labelText: 'Foto URL',
                  hintText: 'https.://... (Opsional)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.link),
                ),
                // Validator sengaja DIKOSONGKAN agar field ini opsional
                validator: (value) {
                  return null; 
                },
              ),
              SizedBox(height: 10),
              //
              // --- AKHIR FIELD BARU ---
              //
              _buildRequiredTextFormField(_namaController, 'Nama Mahasiswa', Icons.person),
              SizedBox(height: 10),
              _buildRequiredTextFormField(_nimController, 'NIM', Icons.badge),
              SizedBox(height: 10),
              _buildRequiredTextFormField(_tglLahirController, 'Tanggal Lahir (DD-MM-YYYY)', Icons.calendar_today),
              SizedBox(height: 10),
              _buildRequiredTextFormField(_hobiController, 'Hobi', Icons.favorite),
              SizedBox(height: 10),
              _buildRequiredTextFormField(_nomorHpController, 'Nomor HP', Icons.phone),
              SizedBox(height: 10),
              _buildRequiredTextFormField(_alamatController, 'Alamat', Icons.home),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitData,
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}