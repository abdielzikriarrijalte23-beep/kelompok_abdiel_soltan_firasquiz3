// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:provider/provider.dart';
import 'providers/theme_provider.dart'; 

// Import semua layar Anda
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/add_edit_screen.dart';
import 'screens/about_screen.dart';
import 'screens/detail_screen.dart'; 
import 'screens/profile_screen.dart'; // <-- RUTE BARU DIIMPORT

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  
  runApp(
    ChangeNotifierProvider(
      create: (context) => ThemeProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();

    return MaterialApp(
      title: 'Flutter CRUD Firebase',
      debugShowCheckedModeBanner: false,
      
      // Konfigurasi Tema (Dark/Light Mode)
      themeMode: themeProvider.themeMode, 
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
      ),

      home: SplashScreen(),
      
      // Daftar Rute Aplikasi
      routes: {
        '/login': (context) => LoginScreen(),
        '/dashboard': (context) => DashboardScreen(),
        '/addEdit': (context) => AddEditScreen(),
        '/about': (context) => AboutScreen(),
        '/detail': (context) => DetailScreen(),
        '/profile': (context) => ProfileScreen(), // <-- RUTE BARU DIDAFTARKAN
      },
    );
  }
}