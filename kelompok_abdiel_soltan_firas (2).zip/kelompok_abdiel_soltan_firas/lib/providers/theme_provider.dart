// lib/providers/theme_provider.dart
import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  // Default-nya kita set ke light mode
  ThemeMode _themeMode = ThemeMode.light;

  // Getter untuk mengambil status tema saat ini
  ThemeMode get themeMode => _themeMode;
  
  // Getter untuk cek apakah sedang dark mode (untuk icon di switch)
  bool get isDarkMode => _themeMode == ThemeMode.dark;

  // Fungsi untuk mengubah tema
  void toggleTheme(bool isOn) {
    _themeMode = isOn ? ThemeMode.dark : ThemeMode.light;
    
    // Beri tahu semua widget yang 'mendengar' bahwa state telah berubah
    notifyListeners(); 
  }
}