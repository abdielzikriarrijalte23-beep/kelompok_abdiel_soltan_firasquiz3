// services/database_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/mahasiswa.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // --- FUNGSI UNTUK LIST MAHASISWA (Dashboard) ---
  // Ini adalah kode Anda yang sudah benar (mengambil dari root 'mahasiswa')
  CollectionReference _getMahasiswaCollection(String userId) {
    return _firestore.collection('mahasiswa');
  }

  Future<void> addMahasiswa(String userId, Mahasiswa mahasiswa) {
    return _getMahasiswaCollection(userId).add(mahasiswa.toMap());
  }

  Stream<QuerySnapshot> getMahasiswaStream(String userId) {
    return _getMahasiswaCollection(userId).snapshots();
  }

  Future<void> updateMahasiswa(String userId, String docId, Mahasiswa mahasiswa) {
    return _getMahasiswaCollection(userId).doc(docId).update(mahasiswa.toMap());
  }

  Future<void> deleteMahasiswa(String userId, String docId) {
    return _getMahasiswaCollection(userId).doc(docId).delete();
  }


  //
  // --- FUNGSI BARU UNTUK PROFIL USER (Layar Profil) ---
  // INI ADALAH BAGIAN YANG HILANG DARI KODE ANDA
  //
  
  // Mendapatkan satu dokumen profil berdasarkan ID user
  Future<DocumentSnapshot?> getUserProfile(String userId) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection('user_profiles') // Koleksi BARU
          .doc(userId) // Dokumen ID = User ID
          .get();
      return doc;
    } catch (e) {
      print(e);
      return null;
    }
  }

  // Membuat atau Memperbarui profil
  Future<void> updateUserProfile(String userId, Map<String, dynamic> data) {
    return _firestore
        .collection('user_profiles') // Koleksi BARU
        .doc(userId) // Dokumen ID = User ID
        .set(data, SetOptions(merge: true)); // 'set' dengan 'merge' akan membuat jika belum ada, atau update jika sudah ada
  }
}